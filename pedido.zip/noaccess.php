<script>
var p = getUrlParameter('attempt');
  if (p=='c') {
</script>
<!DOCTYPE html>
<<html>
<head>
    <script src="js/funciones.js"></script>
</head>
<body>

<p>no access</p>
</body>
</html>