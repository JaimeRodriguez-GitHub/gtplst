<?php

//session_start();
//error_reporting(E_ALL & ~E_NOTICE);

//require_once 'constants.php';
//require_once 'functions.php';

		echo true;
		
// switch ($_GET['action']) {

// 	case 'setLinkDocumentacionSoporte':
// 		//require_once (C_ROOT_DIR.'classes/csPedidos.php');
// 		//$csDatos = new csPedidos();
// 		//$rsResult = $csDatos->setDocumentacionSoporte($_GET['p'],$_GET['filename']);
// 		//echo $rsResult;
// 		echo true;
// 		break;

// 	default:
// 		echo 'invalid function';
// 		break;
// }
?>