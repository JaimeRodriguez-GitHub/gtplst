<?php 
$myArray = array();
$myArray['total'] = 15;

$myDetail['id_vendedor'] = 4;
$myDetail['nombre_vendedor'] = 'BERTHA REYES';
$myDetail['id_cliente'] = 'C00257';
$myDetail['nombre_cliente'] = 'XXALMACEN MARIO QUINTO';
$myDetail['total_solicitado'] = 23423.49;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 4;
$myDetail['nombre_vendedor'] = 'BERTHA REYES';
$myDetail['id_cliente'] = 'C00565';
$myDetail['nombre_cliente'] = 'NINFA DE ENRIQUEZ/REPUESTOS PESADOS DEL NORTE';
$myDetail['total_solicitado'] = 232.43;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 4;
$myDetail['nombre_vendedor'] = 'BERTHA REYES';
$myDetail['id_cliente'] = 'C00257';
$myDetail['nombre_cliente'] = 'ALMACEN MARIO QUINTO';
$myDetail['total_solicitado'] = 6343.23;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 6;
$myDetail['nombre_vendedor'] = 'JULIO GUTIERREZ';
$myDetail['id_cliente'] = 'C00257';
$myDetail['nombre_cliente'] = 'ALMACEN MARIO QUINTO';
$myDetail['total_solicitado'] = 1243.4;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 6;
$myDetail['nombre_vendedor'] = 'JULIO GUTIERREZ';
$myDetail['id_cliente'] = 'C00583';
$myDetail['nombre_cliente'] = 'CENTRO PLASTICO VARIEDADES   (MARCIAL LEIVA)';
$myDetail['total_solicitado'] = 5234;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 4;
$myDetail['nombre_vendedor'] = 'BERTHA REYES';
$myDetail['id_cliente'] = 'C00257';
$myDetail['nombre_cliente'] = 'ALMACEN MARIO QUINTO';
$myDetail['total_solicitado'] = 23423.49;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 4;
$myDetail['nombre_vendedor'] = 'BERTHA REYES';
$myDetail['id_cliente'] = 'C00565';
$myDetail['nombre_cliente'] = 'NINFA DE ENRIQUEZ/REPUESTOS PESADOS DEL NORTE';
$myDetail['total_solicitado'] = 232.43;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 4;
$myDetail['nombre_vendedor'] = 'BERTHA REYES';
$myDetail['id_cliente'] = 'C00257';
$myDetail['nombre_cliente'] = 'ALMACEN MARIO QUINTO';
$myDetail['total_solicitado'] = 6343.23;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 6;
$myDetail['nombre_vendedor'] = 'JULIO GUTIERREZ';
$myDetail['id_cliente'] = 'C00257';
$myDetail['nombre_cliente'] = 'ALMACEN MARIO QUINTO';
$myDetail['total_solicitado'] = 1243.4;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 6;
$myDetail['nombre_vendedor'] = 'JULIO GUTIERREZ';
$myDetail['id_cliente'] = 'C00583';
$myDetail['nombre_cliente'] = 'CENTRO PLASTICO VARIEDADES   (MARCIAL LEIVA)';
$myDetail['total_solicitado'] = 5234;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 4;
$myDetail['nombre_vendedor'] = 'BERTHA REYES';
$myDetail['id_cliente'] = 'C00257';
$myDetail['nombre_cliente'] = 'ALMACEN MARIO QUINTO';
$myDetail['total_solicitado'] = 23423.49;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 4;
$myDetail['nombre_vendedor'] = 'BERTHA REYES';
$myDetail['id_cliente'] = 'C00565';
$myDetail['nombre_cliente'] = 'NINFA DE ENRIQUEZ/REPUESTOS PESADOS DEL NORTE';
$myDetail['total_solicitado'] = 232.43;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 4;
$myDetail['nombre_vendedor'] = 'BERTHA REYES';
$myDetail['id_cliente'] = 'C00257';
$myDetail['nombre_cliente'] = 'ALMACEN MARIO QUINTO';
$myDetail['total_solicitado'] = 6343.23;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 6;
$myDetail['nombre_vendedor'] = 'JULIO GUTIERREZ';
$myDetail['id_cliente'] = 'C00257';
$myDetail['nombre_cliente'] = 'ALMACEN MARIO QUINTO';
$myDetail['total_solicitado'] = 1243.4;
$myArray['rows'][] = $myDetail;

$myDetail['id_vendedor'] = 6;
$myDetail['nombre_vendedor'] = 'JULIO GUTIERREZ';
$myDetail['id_cliente'] = 'C00583';
$myDetail['nombre_cliente'] = 'CENTRO PLASTICO VARIEDADES   (MARCIAL LEIVA)';
$myDetail['total_solicitado'] = 5234;
$myArray['rows'][] = $myDetail;

echo json_encode($myArray);
			
?>